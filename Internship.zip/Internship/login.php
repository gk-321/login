<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "signup";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";


$sql = "SELECT id, email, password, message FROM customers";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"]. " - Name: " . $row["email"]. " " . $row["password"]. "<br>";
	echo $row["message"]. "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();

?>

  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="css/first.css">
    <title> Sign-up </title>
</head>
<body>
     <div class="sign">
        <form action="signup.php" method="post" > 
            <div class="login">
                <h1 class="formtitle">Secret Diary</h1>
                <p>Store your thoughts permanently and securely.</p>
                <p>Interested? Sign up now.</p>
                <input type="text" name="email" class="forminput1" placeholder="Your Email"><br><br>
                <input type="text" name="password" class="forminput1" placeholder="Password"><br><br>
            <div>
            
            <div>
                <input type="checkbox" name="checkbox" id="check" unchecked> <span style="color:white">Stay Logged In</span> <br>
            </div>
            
            
            <input type="submit" name="submit" class="formbutton" value="Sign Up!">
            <p style="color:blue;" ><a href="">Log in </a></p>

        </form>
    </div>
     
     
</body>
</html>



